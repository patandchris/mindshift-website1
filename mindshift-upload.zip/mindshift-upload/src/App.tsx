import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Homepage from "./pages/Homepage";
import Blog from "./pages/Blog";
import Podcast from "./pages/Podcast";
import WeekOneOffer from "./pages/WeekOneOffer";
import Programs from "./pages/Programs";
import About from "./pages/About";
import Sprint from "./pages/Sprint";
import WeekOneComplete from "./pages/WeekOneComplete";
import NotFound from "./pages/NotFound";
import UploadVideo from "./pages/UploadVideo";
import Auth from "./pages/Auth";
import MindshiftApp from "./pages/MindshiftApp";
import WeekOneAccess from "./pages/WeekOneAccess";
import WeekOneContent from "./pages/WeekOneContent";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Homepage />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/podcast" element={<Podcast />} />
          <Route path="/programs" element={<Programs />} />
          <Route path="/about" element={<About />} />
          <Route path="/sprint" element={<Sprint />} />
          <Route path="/week-one-offer" element={<WeekOneOffer />} />
          <Route path="/week-one-access" element={<WeekOneAccess />} />
          <Route path="/week-one-content" element={<WeekOneContent />} />
          <Route path="/week-one-complete" element={<WeekOneComplete />} />
          {/* Legacy redirects */}
          <Route path="/coaching-program" element={<Navigate to="/programs" replace />} />
          <Route path="/auth" element={<Auth />} />
          <Route path="/mindshift-app" element={<MindshiftApp />} />
          <Route path="/upload-video" element={<UploadVideo />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
