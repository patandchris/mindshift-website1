import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle } from "lucide-react";
import { Link } from "react-router-dom";

const weekOneItems = [
  "Identify the specific unconscious beliefs that are limiting your current results",
  "Understand where they were formed — and why they've persisted despite your efforts",
  "Begin loosening them using a structured NLP change pattern",
  "Experience your first guided hypnosis session designed for belief-level change",
];

const BeTheFirstToKnow = () => {
  return (
    <section className="py-16 md:py-20 bg-background">
      <div className="container-premium">
        <div className="max-w-3xl mx-auto">

          <div className="text-center mb-10">
            <h2 className="text-3xl md:text-4xl font-bold text-accent mb-5">
              Week One Is Where the Shift Begins
            </h2>
            <p className="text-xl text-muted-foreground">
              The free Week One isn't a preview or a teaser. It's the first real intervention.
            </p>
          </div>

          <p className="text-lg text-muted-foreground text-center mb-10 max-w-2xl mx-auto">
            Over six audio lessons and two guided exercises, you'll go through the same belief identification and reprogramming process used in the full program:
          </p>

          <div className="space-y-4 mb-10">
            {weekOneItems.map((item, index) => (
              <div key={index} className="flex items-start gap-4">
                <CheckCircle className="h-6 w-6 text-accent flex-shrink-0 mt-0.5" />
                <p className="text-lg text-muted-foreground">{item}</p>
              </div>
            ))}
          </div>

          <p className="text-lg text-muted-foreground text-center mb-10 max-w-2xl mx-auto">
            Most people notice a shift after the first session. Not because they learned something new — because something old stopped running.
          </p>

          <div className="flex flex-col items-center gap-4">
            <Button
              variant="default"
              size="lg"
              className="group bg-gradient-gold text-background font-bold hover:shadow-glow transition-all duration-300"
              asChild
            >
              <Link to="/week-one-offer">
                Start Week One Free
                <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
              </Link>
            </Button>
            <p className="text-sm text-muted-foreground">
              No payment. No commitment. Six audio lessons and two exercises.
            </p>
          </div>

        </div>
      </div>
    </section>
  );
};

export default BeTheFirstToKnow;
