const ProblemSection = () => {
  const symptoms = [
    "You've achieved real things — but a persistent ceiling keeps showing up in your income or your opportunities.",
    "You know what you should do. You just don't consistently do it, and you're not entirely sure why.",
    "You've worked on your mindset. Read the books. Done the courses. The change doesn't stick.",
    "There's a version of yourself you can see clearly — and a gap between that version and where you currently are.",
  ];

  return (
    <section className="section-padding bg-background">
      <div className="container-premium">
        <div className="max-w-3xl mx-auto">

          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-accent mb-6">
              You've Done Everything Right. So Why Are You Still Stuck?
            </h2>
            <p className="text-xl text-muted-foreground">
              Most professionals who reach out to us aren't failing. They're plateaued. And that's a different problem entirely.
            </p>
          </div>

          <div className="space-y-4 mb-12">
            {symptoms.map((symptom, index) => (
              <div key={index} className="flex items-start gap-4 p-5 rounded-xl bg-secondary border border-border">
                <span className="w-2 h-2 rounded-full bg-accent flex-shrink-0 mt-2.5" />
                <p className="text-muted-foreground text-lg leading-relaxed">{symptom}</p>
              </div>
            ))}
          </div>

          <div className="text-center space-y-4">
            <p className="text-lg text-muted-foreground">
              This isn't a knowledge problem. It isn't a strategy problem.
            </p>
            <p className="text-xl font-semibold text-accent">
              It's a programming problem.
            </p>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Your unconscious mind — which drives the vast majority of your behavior — is still running patterns formed decades ago. Patterns built to keep you safe, not successful. Every time you approach the next level, it quietly pulls you back.
            </p>
            <p className="text-lg text-muted-foreground">
              No amount of discipline or strategy fixes a programming-level problem.
            </p>
          </div>

        </div>
      </div>
    </section>
  );
};

export default ProblemSection;
