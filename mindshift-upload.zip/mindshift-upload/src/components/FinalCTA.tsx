import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

const FinalCTA = () => {
  return (
    <section className="section-padding bg-background">
      <div className="container-premium">
        <div className="max-w-2xl mx-auto text-center">

          <h2 className="text-3xl md:text-4xl font-bold text-accent mb-6">
            Changing Your Results Starts Below the Surface
          </h2>

          <p className="text-lg text-muted-foreground mb-4">
            Discipline gets you to 80%. The last 20% — the income ceiling, the persistent self-doubt, the plateau that keeps reappearing — lives in your programming.
          </p>

          <p className="text-lg text-muted-foreground mb-10">
            Week One is where that work begins. It's free. It's structured. And it's the same process that runs through every week of the full program.
          </p>

          <div className="flex flex-col items-center gap-4">
            <Button
              variant="default"
              size="lg"
              className="group bg-gradient-gold text-background font-bold hover:shadow-glow transition-all duration-300"
              asChild
            >
              <Link to="/week-one-offer">
                Start Week One Free
                <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
              </Link>
            </Button>
            <a
              href="https://calendly.com/patandchris/30min"
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm text-muted-foreground hover:text-accent transition-colors underline-offset-4 hover:underline"
            >
              Apply for Private Coaching
            </a>
          </div>

        </div>
      </div>
    </section>
  );
};

export default FinalCTA;
