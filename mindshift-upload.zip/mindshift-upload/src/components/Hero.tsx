import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import mindshiftLogo from "@/assets/mindshift-logo-new.png";

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-background" />

      <div className="container-premium relative z-10">
        <div className="max-w-4xl mx-auto text-center">

          {/* Main Headline */}
          <h1 className="mb-6 mt-24">
            <span className="block text-3xl font-bold md:text-5xl text-accent leading-tight">
              Your Unconscious Programming<br className="hidden md:block" /> Is Running Your Results
            </span>
          </h1>

          {/* Logo */}
          <div className="flex justify-center mb-6">
            <div className="px-[36px] py-[48px] mx-[100px]">
              <img
                src={mindshiftLogo}
                alt="The MindShift System"
                className="w-full max-w-2xl mx-auto md:max-w-3xl"
              />
            </div>
          </div>

          {/* Subheadline */}
          <p className="text-xl font-semibold text-muted-foreground mb-6 px-[8px] md:text-2xl">
            The 12-Week Unconscious Upgrade
          </p>

          {/* Description */}
          <p className="text-lg text-muted-foreground mb-12 max-w-2xl mx-auto">
            Most professionals hit a ceiling — not from lack of skill or effort, but because their unconscious mind is still running old software. MindShift uses NLP and hypnosis to rewrite that programming at the source.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col items-center gap-4">
            <Link to="/week-one-offer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
              <Button variant="default" size="lg" className="group bg-gradient-gold text-background font-bold hover:shadow-glow transition-all duration-300">
                Start Week One Free
                <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
              </Button>
            </Link>
            <a
              href="https://calendly.com/patandchris/30min"
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm text-muted-foreground hover:text-accent transition-colors underline-offset-4 hover:underline"
            >
              Apply for Private Coaching
            </a>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Hero;
