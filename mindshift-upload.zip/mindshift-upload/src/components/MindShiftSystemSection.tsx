import { Brain, Zap, Target } from "lucide-react";

const MindShiftSystemSection = () => {
  const steps = [
    {
      icon: Target,
      heading: "Identify",
      body: "Surface the specific unconscious beliefs that are generating your current ceiling — most of which you've never consciously examined.",
    },
    {
      icon: Brain,
      heading: "Dissolve",
      body: "Use NLP change patterns to loosen the certainty that keeps those beliefs locked in place. Not by arguing with them — by changing how your mind holds them.",
    },
    {
      icon: Zap,
      heading: "Reprogram",
      body: "Install new internal standards through clinical hypnosis, at the level where behavior is actually generated — not on top of it.",
    },
  ];

  return (
    <section className="section-padding bg-background">
      <div className="container-premium">
        <div className="max-w-4xl mx-auto">

          <div className="text-center mb-14">
            <h2 className="text-3xl md:text-4xl font-bold text-accent mb-6">
              MindShift Rewrites the Patterns — Not Just the Behavior
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Most coaching works at the conscious level — goals, actions, accountability. MindShift works at the level beneath that.
            </p>
          </div>

          <p className="text-lg text-muted-foreground text-center max-w-2xl mx-auto mb-12">
            Using NLP change patterns and clinical hypnosis, the program targets the unconscious structures driving your current results and replaces them with patterns aligned with where you want to go.
          </p>

          <div className="grid md:grid-cols-3 gap-6 mb-12">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <div key={index} className="text-center p-6 rounded-xl bg-secondary border border-border">
                  <div className="w-14 h-14 bg-accent/10 border border-accent/30 rounded-xl flex items-center justify-center mx-auto mb-5">
                    <Icon className="w-7 h-7 text-accent" />
                  </div>
                  <h3 className="text-xl font-bold text-accent mb-3">{step.heading}</h3>
                  <p className="text-muted-foreground leading-relaxed">{step.body}</p>
                </div>
              );
            })}
          </div>

          <p className="text-center text-lg text-muted-foreground max-w-2xl mx-auto">
            The result isn't motivation. It's a fundamental shift in how your mind processes opportunity, risk, and your own worth — so the right actions happen more naturally.
          </p>

        </div>
      </div>
    </section>
  );
};

export default MindShiftSystemSection;
