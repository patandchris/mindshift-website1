import Header from "@/components/Header";
import Hero from "@/components/Hero";
import ProblemSection from "@/components/ProblemSection";
import MindShiftSystemSection from "@/components/MindShiftSystemSection";
import SuccessStories from "@/components/SuccessStories";
import BeTheFirstToKnow from "@/components/BeTheFirstToKnow";
import PodcastPromo from "@/components/PodcastPromo";
import FinalCTA from "@/components/FinalCTA";
import Footer from "@/components/Footer";
import { Separator } from "@/components/ui/separator";

const Divider = () => (
  <div className="container-premium py-8">
    <Separator className="bg-gradient-to-r from-transparent via-accent to-transparent h-[2px]" />
  </div>
);

const Homepage = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {/* 1 — Hero */}
        <Hero />
        <Divider />

        {/* 2 — Problem */}
        <ProblemSection />
        <Divider />

        {/* 3 — The System */}
        <MindShiftSystemSection />
        <Divider />

        {/* 4 — Social proof */}
        <SuccessStories />
        <Divider />

        {/* 5 — Week One explanation + CTA */}
        <BeTheFirstToKnow />
        <Divider />

        {/* 6 — Podcast */}
        <PodcastPromo />
        <Divider />

        {/* 7 — Final CTA */}
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
};

export default Homepage;
