import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { CheckCircle, ArrowRight, Lock } from "lucide-react";
import { Link } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

const weeks = [
  {
    number: 1,
    title: "Control the Mind",
    description:
      "Establish conscious authority over your internal state. Stop automatic patterns from running unexamined and begin directing your thinking deliberately.",
  },
  {
    number: 2,
    title: "Challenge Limiting Beliefs",
    description:
      "Identify and begin dissolving the core beliefs suppressing your results. The NLP change pattern used here directly loosens the certainty that keeps limiting beliefs in place.",
  },
  {
    number: 3,
    title: "Shift Perspective",
    description:
      "Interrupt the fixed frames through which you've been interpreting your career, income, and potential. Most perceived limitations are perspective problems, not reality problems.",
  },
  {
    number: 4,
    title: "Take Leadership",
    description:
      "Install internal leadership patterns. Begin operating from accountability and ownership rather than from avoidance or the need for external validation.",
  },
  {
    number: 5,
    title: "Remove Hidden Blocks",
    description:
      "Target secondary layers of unconscious resistance — the blocks that reappear after surface-level beliefs have been addressed. These are often the oldest and most identity-tied patterns.",
  },
  {
    number: 6,
    title: "Future Identity",
    description:
      "Close with a forward installation. Anchor a new identity baseline — who you are becoming — so the unconscious mind starts pulling you toward it rather than away from it.",
  },
];

const outcomes = [
  "Internal resistance begins to disappear from decisions that previously felt difficult",
  "Limiting beliefs stop feeling true — they're still present, but they no longer feel like facts",
  "Decisions about career, income, and opportunities become easier and faster",
  "You find yourself taking actions you previously avoided without needing to force it",
  "The people around you notice a change before you can fully articulate it yourself",
];

const SprintCTA = ({ label = "Start the MindShift Sprint — $397" }: { label?: string }) => {
  const { toast } = useToast();
  return (
    <Button
      variant="default"
      size="lg"
      className="group bg-gradient-gold text-background font-bold hover:shadow-glow transition-all duration-300"
      onClick={() =>
        toast({
          title: "Checkout coming soon",
          description: "Payment integration is being finalised. Check back shortly.",
        })
      }
    >
      {label}
      <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
    </Button>
  );
};

const Sprint = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main>
        {/* ── Hero ── */}
        <section className="section-padding bg-background">
          <div className="container-premium">
            <div className="max-w-3xl mx-auto text-center pt-16">
              <div className="inline-flex items-center px-4 py-1.5 rounded-full bg-accent/10 border border-accent/30 text-accent text-sm font-semibold mb-6">
                6-Week Program · Self-Serve · $397
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-accent mb-6 leading-tight">
                Break the Unconscious Programming Limiting Your Success and Income
              </h1>
              <p className="text-xl text-muted-foreground mb-10 max-w-2xl mx-auto">
                The MindShift Sprint is a structured 6-week intervention. Each week targets a specific layer of unconscious programming using NLP change patterns and clinical hypnosis — applied to the patterns keeping capable professionals stuck.
              </p>
              <div className="flex flex-col items-center gap-3">
                <SprintCTA />
                <p className="text-sm text-muted-foreground">
                  No calls. No application. Starts immediately after purchase.
                </p>
              </div>
            </div>
          </div>
        </section>

        <div className="container-premium">
          <Separator className="bg-gradient-to-r from-transparent via-accent to-transparent h-[2px]" />
        </div>

        {/* ── Recognition ── */}
        <section className="section-padding bg-background">
          <div className="container-premium">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-accent mb-8 text-center">
                You're Not Stuck Because You're Not Trying Hard Enough.
              </h2>
              <div className="space-y-5 text-lg text-muted-foreground">
                <p>
                  You've built real skills. Put in real work. Applied real strategy. And you keep running into the same ceiling — in your income, your confidence, the opportunities you pursue or avoid.
                </p>
                <p>
                  The ceiling isn't in your schedule. It isn't in your network. It isn't in your market.
                </p>
                <p className="text-accent font-semibold text-xl">
                  It's in the unconscious programming that determines what you do when no one is watching.
                </p>
                <p>
                  That programming determines what you pursue or avoid without consciously deciding to — and what you believe is actually available to you. It's why people with identical skill sets get different results. It's why the same strategies work for some and don't for others. It's why you can read the right book and do nothing with it.
                </p>
              </div>
            </div>
          </div>
        </section>

        <div className="container-premium">
          <Separator className="bg-gradient-to-r from-transparent via-accent to-transparent h-[2px]" />
        </div>

        {/* ── Why Most Approaches Fail ── */}
        <section className="section-padding bg-background">
          <div className="container-premium">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-accent mb-8 text-center">
                Most Personal Development Targets the Wrong Level.
              </h2>
              <div className="space-y-5 text-lg text-muted-foreground">
                <p>
                  Books, courses, coaching, and accountability all operate at the level of conscious behavior. They tell you what to do and hold you accountable for doing it. That's useful — until you hit the unconscious layer where behavior is actually generated.
                </p>
                <p>
                  At that level, you don't need more information. You need a direct intervention in the programming producing your current results.
                </p>
                <p>
                  NLP change patterns and hypnosis are tools that operate at that level. Not motivationally — mechanically. They work directly on how the unconscious mind holds beliefs, processes threat, and generates behavior. The change doesn't require willpower to sustain because it happens at the source.
                </p>
              </div>
            </div>
          </div>
        </section>

        <div className="container-premium">
          <Separator className="bg-gradient-to-r from-transparent via-accent to-transparent h-[2px]" />
        </div>

        {/* ── 6-Week Journey ── */}
        <section className="section-padding bg-background">
          <div className="container-premium">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-accent mb-4">
                  Six Weeks. One Layer of Programming Per Week.
                </h2>
                <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                  The Sprint is a structured intervention with a specific arc. Each week builds on the last — content unlocks on a 7-day cadence after purchase to preserve the program structure.
                </p>
              </div>

              <div className="space-y-4">
                {weeks.map((week) => (
                  <div
                    key={week.number}
                    className="flex gap-5 p-6 rounded-xl bg-secondary border border-border"
                  >
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-accent/10 border border-accent/30 flex items-center justify-center">
                      <span className="text-accent font-bold text-sm">{week.number}</span>
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-accent mb-1">
                        Week {week.number} — {week.title}
                      </h3>
                      <p className="text-muted-foreground leading-relaxed">{week.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <div className="container-premium">
          <Separator className="bg-gradient-to-r from-transparent via-accent to-transparent h-[2px]" />
        </div>

        {/* ── Client Outcomes ── */}
        <section className="section-padding bg-background">
          <div className="container-premium">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-accent mb-4 text-center">
                What Clients Often Notice
              </h2>
              <p className="text-xl text-muted-foreground text-center mb-10">
                Results from unconscious reprogramming don't always arrive the way people expect. It's rarely a dramatic event. More often:
              </p>
              <div className="space-y-4">
                {outcomes.map((outcome, i) => (
                  <div key={i} className="flex items-start gap-4">
                    <CheckCircle className="h-6 w-6 text-accent flex-shrink-0 mt-0.5" />
                    <p className="text-lg text-muted-foreground">{outcome}</p>
                  </div>
                ))}
              </div>
              <p className="text-muted-foreground mt-8 text-center italic">
                The shift isn't always visible from the inside first. The programming that was limiting you was also invisible — until it started loosening.
              </p>
            </div>
          </div>
        </section>

        <div className="container-premium">
          <Separator className="bg-gradient-to-r from-transparent via-accent to-transparent h-[2px]" />
        </div>

        {/* ── Testimonial ── */}
        <section className="section-padding bg-background">
          <div className="container-premium">
            <div className="max-w-2xl mx-auto">
              <p className="text-center text-sm text-accent font-semibold uppercase tracking-widest mb-8">
                Client Result
              </p>
              <Card className="bg-secondary border border-border">
                <CardContent className="p-8">
                  <p className="text-sm text-accent font-medium mb-4">
                    Haroldo Chacon — Aerospace Structural Engineer — went through the MindShift program and found that his results changed before his strategy did. That's what happens when the programming changes.
                  </p>
                  <blockquote className="text-lg text-muted-foreground italic leading-relaxed mb-6">
                    "By applying all aspects covered by this MindShift Coaching Program, I've been noticing significant changes regarding the way I think, my actions and beliefs. This is bringing me unexpected results, awareness, and new knowledge in areas that I've never thought possible before. It's like opening a treasure chest every day, and it's really changing my behaviors and my life!"
                  </blockquote>
                  <p className="text-accent font-semibold">— Haroldo Chacon</p>
                  <p className="text-sm text-muted-foreground">Aerospace Structural Engineer · Started 2 new business ventures</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <div className="container-premium">
          <Separator className="bg-gradient-to-r from-transparent via-accent to-transparent h-[2px]" />
        </div>

        {/* ── Price Block ── */}
        <section className="section-padding bg-background">
          <div className="container-premium">
            <Card className="max-w-2xl mx-auto bg-secondary border border-border">
              <CardContent className="p-10 flex flex-col items-center text-center">
                <h2 className="text-3xl font-bold text-accent mb-2">MindShift Sprint</h2>
                <p className="text-muted-foreground mb-6">6-week unconscious reprogramming program</p>

                <div className="space-y-3 text-left w-full max-w-sm mb-8">
                  {[
                    "Six weeks of structured audio content",
                    "One NLP change pattern per week",
                    "One guided hypnosis session per week",
                    "Reflection exercises for integration",
                    "Progress tracking in your member dashboard",
                    "Weekly content unlock (7-day cadence)",
                    "Lifetime access to your six weeks",
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 text-accent flex-shrink-0" />
                      <span className="text-muted-foreground">{item}</span>
                    </div>
                  ))}
                </div>

                <div className="mb-6">
                  <span className="text-5xl font-black text-accent">$397</span>
                  <span className="text-muted-foreground ml-2">one payment</span>
                </div>

                <SprintCTA />
                <p className="text-xs text-muted-foreground mt-4">
                  Secure checkout. Immediate access to Week 1. Weeks 2–6 unlock weekly.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        <div className="container-premium">
          <Separator className="bg-gradient-to-r from-transparent via-accent to-transparent h-[2px]" />
        </div>

        {/* ── Final CTA ── */}
        <section className="section-padding bg-background">
          <div className="container-premium">
            <div className="max-w-2xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold text-accent mb-5">
                Your Programming Has Been Running Your Results for Decades.
              </h2>
              <p className="text-lg text-muted-foreground mb-4">
                The Sprint changes that — in six weeks, using the same tools clinical practitioners use to produce unconscious change at the source.
              </p>
              <p className="text-lg text-muted-foreground mb-10">
                You've already seen what Week One does. The Sprint goes five weeks deeper.
              </p>
              <div className="flex flex-col items-center gap-4">
                <SprintCTA />
                <Link
                  to="/week-one-offer"
                  className="text-sm text-muted-foreground hover:text-accent transition-colors underline-offset-4 hover:underline"
                >
                  Not started yet? Try Week One free first
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Sprint;
