import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import patChrisLogo from "@/assets/pat-chris-logo.png";

const About = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main>
        {/* Hero */}
        <section className="section-padding bg-background">
          <div className="container-premium">
            <div className="max-w-3xl mx-auto text-center pt-16">
              <div className="flex justify-center mb-8">
                <img src={patChrisLogo} alt="Pat & Chris Coaching" className="h-24 w-auto" />
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-accent mb-6">
                About Pat & Chris
              </h1>
              <p className="text-xl text-muted-foreground">
                We built The MindShift System because we lived the problem first.
              </p>
            </div>
          </div>
        </section>

        {/* Gold Divider */}
        <div className="container-premium">
          <Separator className="bg-gradient-to-r from-transparent via-accent to-transparent h-[2px]" />
        </div>

        {/* Story */}
        <section className="section-padding bg-background">
          <div className="container-premium">
            <div className="max-w-3xl mx-auto space-y-8 text-muted-foreground text-lg leading-relaxed">
              <p>
                Pat and Chris are mindset coaches, podcasters, and creators of The MindShift System — a proven framework that helps ambitious professionals break through limiting beliefs, eliminate self-sabotage, and step into the life and results they know they're capable of.
              </p>
              <p>
                After years of working with high-achievers who were doing everything "right" but still feeling stuck, they identified a common pattern: the real obstacle wasn't skill, strategy, or effort. It was the unconscious programming running underneath — the beliefs, habits, and identity stories keeping people locked in place.
              </p>
              <p>
                The MindShift System was designed to solve that at the root. Not with more productivity hacks or motivational content — but with deep, lasting unconscious reprogramming that creates change that actually sticks.
              </p>
              <p>
                Today, Pat and Chris coach clients one-on-one, run group programs, and host the Make A Move podcast — bringing the MindShift framework to a global audience of men ready to build a life on their own terms.
              </p>
            </div>
          </div>
        </section>

        {/* Gold Divider */}
        <div className="container-premium">
          <Separator className="bg-gradient-to-r from-transparent via-accent to-transparent h-[2px]" />
        </div>

        {/* CTA */}
        <section className="section-padding bg-background">
          <div className="container-premium">
            <div className="max-w-2xl mx-auto text-center">
              <h2 className="text-2xl md:text-3xl font-bold text-accent mb-4">
                Ready to Experience It for Yourself?
              </h2>
              <p className="text-lg text-muted-foreground mb-8">
                Start with Week One — completely free. No commitment, no credit card.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <Button
                  variant="default"
                  size="lg"
                  className="group bg-gradient-gold text-background font-bold hover:shadow-glow transition-all duration-300"
                  asChild
                >
                  <Link to="/week-one-offer">
                    Start Week One Free
                    <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
                  </Link>
                </Button>
                <a
                  href="https://calendly.com/patandchris/30min"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-muted-foreground hover:text-accent transition-colors underline-offset-4 hover:underline"
                >
                  Apply for Private Coaching
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default About;
