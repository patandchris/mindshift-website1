import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { ArrowRight, CheckCircle, Lock, Loader2 } from "lucide-react";
import mindshiftLogo from "@/assets/mindshift-logo-new.png";

const sprintWeeks = [
  { number: 1, title: "Control the Mind", done: true },
  { number: 2, title: "Challenge Limiting Beliefs", done: false },
  { number: 3, title: "Shift Perspective", done: false },
  { number: 4, title: "Take Leadership", done: false },
  { number: 5, title: "Remove Hidden Blocks", done: false },
  { number: 6, title: "Future Identity", done: false },
];

const WeekOneComplete = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) {
        navigate("/week-one-access", { replace: true });
      } else {
        setLoading(false);
      }
    });
  }, [navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Minimal header */}
      <header className="bg-card/50 border-b border-border">
        <div className="container-premium py-4 flex justify-center">
          <img src={mindshiftLogo} alt="MindShift System" className="h-16" />
        </div>
      </header>

      <main className="flex-1 container-premium py-16 max-w-2xl mx-auto w-full">

        {/* Completion badge */}
        <div className="flex justify-center mb-8">
          <div className="w-20 h-20 rounded-full bg-accent/10 border-2 border-accent flex items-center justify-center">
            <CheckCircle className="w-10 h-10 text-accent" />
          </div>
        </div>

        {/* Headline */}
        <h1 className="text-3xl md:text-4xl font-bold text-accent text-center mb-4">
          You Just Experienced the First Step of the MindShift System
        </h1>
        <p className="text-lg text-muted-foreground text-center mb-10">
          This wasn't a preview. That was the real process.
        </p>

        <div className="container-premium">
          <Separator className="bg-gradient-to-r from-transparent via-accent to-transparent h-[2px] mb-10" />
        </div>

        {/* What just happened */}
        <div className="space-y-4 text-muted-foreground text-lg mb-10">
          <p>
            This week you did what most people never do: you worked directly with the unconscious programming that has been quietly shaping your results.
          </p>
          <p>
            You identified beliefs you've likely never examined consciously. You experienced how an NLP change pattern loosens the certainty holding them in place. You went through your first guided hypnosis session designed for belief-level change.
          </p>
          <p>
            That's the MindShift mechanism. And you just ran it for the first time.
          </p>
        </div>

        {/* Bridge */}
        <div className="bg-secondary border border-border rounded-xl p-6 mb-10">
          <p className="text-accent font-semibold text-lg mb-4">
            Week One addressed one layer of unconscious programming. The MindShift Sprint goes through six.
          </p>
          <p className="text-muted-foreground">
            Each week builds on the last — targeting a deeper layer of the programming that limits success, income, and identity. By Week 6, most clients are operating from a fundamentally different internal baseline.
          </p>
        </div>

        {/* Sprint week arc */}
        <div className="space-y-3 mb-10">
          {sprintWeeks.map((week) => (
            <div
              key={week.number}
              className={`flex items-center gap-4 p-4 rounded-lg border ${
                week.done
                  ? "bg-accent/5 border-accent/30"
                  : "bg-secondary border-border opacity-70"
              }`}
            >
              <div className="flex-shrink-0">
                {week.done ? (
                  <CheckCircle className="w-5 h-5 text-accent" />
                ) : (
                  <Lock className="w-5 h-5 text-muted-foreground" />
                )}
              </div>
              <span
                className={`font-medium ${
                  week.done ? "text-accent" : "text-muted-foreground"
                }`}
              >
                Week {week.number} — {week.title}
              </span>
              {week.done && (
                <span className="ml-auto text-xs text-accent font-semibold uppercase tracking-wide">
                  Complete
                </span>
              )}
            </div>
          ))}
        </div>

        <div className="container-premium">
          <Separator className="bg-gradient-to-r from-transparent via-accent to-transparent h-[2px] mb-10" />
        </div>

        {/* CTA */}
        <div className="text-center">
          <h2 className="text-2xl font-bold text-accent mb-3">
            Continue Your Transformation
          </h2>
          <p className="text-muted-foreground mb-8">
            Unlock the full MindShift Sprint — six weeks of NLP and hypnosis applied to the specific programming limiting your success and income.
          </p>

          <div className="flex flex-col items-center gap-4">
            <Button
              variant="default"
              size="lg"
              className="group bg-gradient-gold text-background font-bold hover:shadow-glow transition-all duration-300"
              asChild
            >
              <Link to="/sprint">
                Continue Your Transformation — Start the MindShift Sprint
                <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
              </Link>
            </Button>
            <Link
              to="/week-one-content"
              className="text-sm text-muted-foreground hover:text-accent transition-colors underline-offset-4 hover:underline"
            >
              Go back to Week One content
            </Link>
          </div>
        </div>

      </main>

      <footer className="border-t border-border">
        <div className="container-premium py-6">
          <p className="text-center text-sm text-muted-foreground">
            © {new Date().getFullYear()} Pat & Chris Coaching. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default WeekOneComplete;
