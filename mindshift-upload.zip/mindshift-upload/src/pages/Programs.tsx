import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ArrowRight, Zap, Brain } from "lucide-react";
import { Link } from "react-router-dom";

const Programs = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main>
        {/* Hero */}
        <section className="section-padding bg-background">
          <div className="container-premium">
            <div className="max-w-3xl mx-auto text-center pt-16">
              <h1 className="text-4xl md:text-5xl font-bold text-accent mb-6">
                Choose Your Path
              </h1>
              <p className="text-xl text-muted-foreground mb-4">
                Whether you're looking for a focused sprint or a complete identity overhaul, The MindShift System has a program designed to meet you where you are.
              </p>
              <p className="text-base text-muted-foreground">
                Not sure where to start?{" "}
                <Link to="/week-one-offer" className="text-accent hover:underline underline-offset-4">
                  Try Week One free
                </Link>{" "}
                — no commitment required.
              </p>
            </div>
          </div>
        </section>

        {/* Gold Divider */}
        <div className="container-premium">
          <Separator className="bg-gradient-to-r from-transparent via-accent to-transparent h-[2px]" />
        </div>

        {/* Program Cards */}
        <section className="section-padding bg-background">
          <div className="container-premium">
            <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">

              {/* 6-Week Sprint */}
              <Card className="bg-secondary border border-border flex flex-col">
                <CardContent className="p-8 flex flex-col flex-1">
                  <div className="w-14 h-14 bg-accent/10 border border-accent/30 rounded-xl flex items-center justify-center mb-6">
                    <Zap className="w-7 h-7 text-accent" />
                  </div>
                  <div className="inline-flex items-center px-3 py-1 rounded-full bg-accent/10 border border-accent/20 text-accent text-sm font-medium mb-4 self-start">
                    6 Weeks
                  </div>
                  <h2 className="text-2xl font-bold text-accent mb-4">
                    MindShift Sprint
                  </h2>
                  <p className="text-muted-foreground mb-6 flex-1">
                    A focused 6-week intensive designed for professionals who need rapid, targeted results. You'll identify your core limiting beliefs, install the habits that drive breakthrough performance, and walk away with a clear, repeatable system — in half the time.
                  </p>
                  <ul className="space-y-2 text-sm text-muted-foreground mb-8">
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-accent flex-shrink-0" />
                      Identify and dissolve your primary limiting belief
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-accent flex-shrink-0" />
                      Install 3 high-leverage success habits
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-accent flex-shrink-0" />
                      Weekly live coaching sessions
                    </li>
                  </ul>
                  <Button
                    variant="default"
                    size="lg"
                    className="w-full group bg-gradient-gold text-background font-bold hover:shadow-glow transition-all duration-300"
                    asChild
                  >
                    <Link to="/sprint">
                      Get the MindShift Sprint
                      <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              {/* 12-Week Identity Transformation */}
              <Card className="bg-secondary border border-border flex flex-col">
                <CardContent className="p-8 flex flex-col flex-1">
                  <div className="w-14 h-14 bg-accent/10 border border-accent/30 rounded-xl flex items-center justify-center mb-6">
                    <Brain className="w-7 h-7 text-accent" />
                  </div>
                  <div className="inline-flex items-center px-3 py-1 rounded-full bg-accent/10 border border-accent/20 text-accent text-sm font-medium mb-4 self-start">
                    12 Weeks
                  </div>
                  <h2 className="text-2xl font-bold text-accent mb-4">
                    Identity Transformation
                  </h2>
                  <p className="text-muted-foreground mb-6 flex-1">
                    The full MindShift System experience. Over 12 weeks, you'll rewire your unconscious mind at the deepest level — eliminating self-sabotage, rebuilding your identity, and locking in permanent transformation across your life, career, and relationships.
                  </p>
                  <ul className="space-y-2 text-sm text-muted-foreground mb-8">
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-accent flex-shrink-0" />
                      Complete unconscious belief rewiring
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-accent flex-shrink-0" />
                      Identity-level habit installation
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-accent flex-shrink-0" />
                      Full focus optimization system
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-accent flex-shrink-0" />
                      Weekly live coaching + accountability
                    </li>
                  </ul>
                  <a
                    href="https://calendly.com/patandchris/30min"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Button
                      variant="default"
                      size="lg"
                      className="w-full group bg-gradient-gold text-background font-bold hover:shadow-glow transition-all duration-300"
                    >
                      Apply for Private Coaching
                      <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
                    </Button>
                  </a>
                </CardContent>
              </Card>

            </div>
          </div>
        </section>

        {/* Gold Divider */}
        <div className="container-premium">
          <Separator className="bg-gradient-to-r from-transparent via-accent to-transparent h-[2px]" />
        </div>

        {/* Start Free CTA */}
        <section className="section-padding bg-background">
          <div className="container-premium">
            <Card className="max-w-2xl mx-auto bg-secondary border border-border">
              <CardContent className="p-12 flex flex-col items-center text-center">
                <h2 className="text-2xl md:text-3xl font-bold text-accent mb-4">
                  Not Ready to Commit Yet?
                </h2>
                <p className="text-lg text-muted-foreground mb-8">
                  Start with Week One — completely free. Experience the MindShift method for yourself before making any decision.
                </p>
                <Button
                  variant="default"
                  size="lg"
                  className="group bg-gradient-gold text-background font-bold hover:shadow-glow transition-all duration-300"
                  asChild
                >
                  <Link to="/week-one-offer">
                    Start Week One Free
                    <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Programs;
