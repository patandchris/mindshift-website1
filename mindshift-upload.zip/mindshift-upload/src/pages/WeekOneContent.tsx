import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Progress } from '@/components/ui/progress';
import { Loader2, LogOut, Lock, CheckCircle, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import AudioLessonCard from '@/components/week1/AudioLessonCard';
import DocumentCard from '@/components/week1/DocumentCard';
import mindshiftLogo from '@/assets/mindshift-logo-new.png';
import type { User } from '@supabase/supabase-js';

interface ContentItem {
  id: string;
  title: string;
  description: string | null;
  content_type: string;
  file_url: string | null;
  display_order: number;
  duration_seconds: number | null;
}

interface ProgressItem {
  content_id: string;
  is_completed: boolean;
  playback_position: number;
}

interface MemberData {
  id: string;
  progress_percentage: number;
  status: string;
  sprint_access?: boolean; // populated by payment integration
}

const sprintWeeks = [
  { number: 1, title: 'Control the Mind' },
  { number: 2, title: 'Challenge Limiting Beliefs' },
  { number: 3, title: 'Shift Perspective' },
  { number: 4, title: 'Take Leadership' },
  { number: 5, title: 'Remove Hidden Blocks' },
  { number: 6, title: 'Future Identity' },
];

const WeekOneContent = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState<ContentItem[]>([]);
  const [progress, setProgress] = useState<Record<string, ProgressItem>>({});
  const [memberData, setMemberData] = useState<MemberData | null>(null);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate('/week-one-access');
        return;
      }
      setUser(session.user);
      await loadContent(session.user.id);
    };

    checkAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!session) {
        navigate('/week-one-access');
      } else {
        setUser(session.user);
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const loadContent = async (userId: string) => {
    try {
      const { data: contentData, error: contentError } = await supabase
        .from('week1_content')
        .select('*')
        .order('display_order');

      if (contentError) throw contentError;
      setContent(contentData || []);

      let { data: member, error: memberError } = await supabase
        .from('week1_members')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle();

      if (memberError && memberError.code !== 'PGRST116') throw memberError;

      if (!member) {
        const { data: { user } } = await supabase.auth.getUser();
        const { data: newMember, error: insertError } = await supabase
          .from('week1_members')
          .insert({
            user_id: userId,
            email: user?.email || '',
            status: 'not_started',
          })
          .select()
          .single();

        if (insertError) throw insertError;
        member = newMember;
      }

      setMemberData(member);

      const { data: progressData, error: progressError } = await supabase
        .from('member_content_progress')
        .select('*')
        .eq('member_id', member.id);

      if (progressError) throw progressError;

      const progressMap: Record<string, ProgressItem> = {};
      progressData?.forEach(p => {
        progressMap[p.content_id] = {
          content_id: p.content_id,
          is_completed: p.is_completed,
          playback_position: p.playback_position || 0,
        };
      });
      setProgress(progressMap);
    } catch (error: any) {
      toast({
        title: 'Error loading content',
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const updateProgress = async (contentId: string, isCompleted: boolean, playbackPosition?: number) => {
    if (!memberData) return;

    try {
      const { error } = await supabase
        .from('member_content_progress')
        .upsert({
          member_id: memberData.id,
          content_id: contentId,
          is_completed: isCompleted,
          playback_position: playbackPosition || 0,
          started_at: new Date().toISOString(),
          completed_at: isCompleted ? new Date().toISOString() : null,
          updated_at: new Date().toISOString(),
        }, {
          onConflict: 'member_id,content_id',
        });

      if (error) throw error;

      setProgress(prev => ({
        ...prev,
        [contentId]: {
          content_id: contentId,
          is_completed: isCompleted,
          playback_position: playbackPosition || prev[contentId]?.playback_position || 0,
        }
      }));

      const { data: updatedMember } = await supabase
        .from('week1_members')
        .select('*')
        .eq('id', memberData.id)
        .single();

      if (updatedMember) {
        setMemberData(updatedMember);
        // Auto-redirect to completion page when final item is marked done
        if (updatedMember.progress_percentage === 100) {
          navigate('/week-one-complete');
        }
      }
    } catch (error: any) {
      toast({
        title: 'Error saving progress',
        description: error.message,
        variant: 'destructive',
      });
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/week-one-access');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  const audioContent = content.filter(c => c.content_type === 'audio');
  const documentContent = content.filter(c => c.content_type === 'pdf' || c.content_type === 'document');
  const sprintUnlocked = memberData?.sprint_access === true;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card/50 border-b border-border sticky top-0 z-50 backdrop-blur-lg">
        <div className="container-premium py-6">
          <div className="flex items-center justify-between">
            <div className="w-48" />
            <img src={mindshiftLogo} alt="MindShift System" className="h-20 md:h-24" />
            <div className="flex items-center gap-6">
              <Button
                variant="default"
                size="lg"
                className="h-12 px-6 bg-gradient-gold text-background font-bold hover:shadow-glow transition-all duration-300"
                asChild
              >
                <Link to="/sprint">Unlock the MindShift Sprint</Link>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLogout}
                className="text-muted-foreground hover:text-foreground"
              >
                <LogOut className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">Sign Out</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container-premium py-8">
        {/* Week Title */}
        <h1 className="font-semibold mb-6">
          <span className="text-accent">Week 1:</span>{' '}
          <span className="text-muted-foreground">Control the Mind</span>
        </h1>

        {/* Progress */}
        <div className="mb-10">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-base font-semibold text-accent">Your Progress</h2>
            <span className="text-accent font-bold">{memberData?.progress_percentage || 0}%</span>
          </div>
          <Progress value={memberData?.progress_percentage || 0} className="h-3 w-full" />
          <p className="text-sm text-muted-foreground mt-2">
            {memberData?.progress_percentage === 100
              ? '✓ Week One complete. Continue to the Sprint.'
              : memberData?.progress_percentage && memberData.progress_percentage > 0
                ? 'Keep going — complete all lessons to finish Week One.'
                : 'Start your first lesson to begin.'}
          </p>
        </div>

        {/* Audio Lessons */}
        <section className="mb-10">
          <h2 className="font-semibold text-accent mb-6">Audio Lessons</h2>
          <div className="space-y-4">
            {audioContent.map((item) => (
              <AudioLessonCard
                key={item.id}
                id={item.id}
                title={item.title}
                description={item.description || ''}
                fileUrl={item.file_url}
                duration={item.duration_seconds}
                isCompleted={progress[item.id]?.is_completed || false}
                playbackPosition={progress[item.id]?.playback_position || 0}
                onComplete={(completed) => updateProgress(item.id, completed)}
                onProgressUpdate={(position) => updateProgress(item.id, progress[item.id]?.is_completed || false, position)}
              />
            ))}
          </div>
        </section>

        {/* Documents */}
        <section className="mb-12">
          <h2 className="font-semibold text-accent mb-6">Exercises & Resources</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            {documentContent.map((item) => (
              <DocumentCard
                key={item.id}
                id={item.id}
                title={item.title}
                description={item.description || ''}
                fileUrl={item.file_url}
                contentType={item.content_type}
                isCompleted={progress[item.id]?.is_completed || false}
                onComplete={(completed) => updateProgress(item.id, completed)}
              />
            ))}
          </div>
        </section>

        {/* Sprint Week Lock Dashboard */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-semibold text-accent">Your Program</h2>
            {!sprintUnlocked && (
              <Link
                to="/sprint"
                className="text-sm text-accent hover:underline underline-offset-4 transition-colors"
              >
                Unlock all weeks →
              </Link>
            )}
          </div>

          <div className="space-y-3">
            {sprintWeeks.map((week) => {
              const isWeekOne = week.number === 1;
              const isUnlocked = isWeekOne || sprintUnlocked;
              const weekComplete = isWeekOne && (memberData?.progress_percentage || 0) === 100;

              return (
                <div
                  key={week.number}
                  className={`flex items-center gap-4 p-4 rounded-lg border transition-colors ${
                    isUnlocked
                      ? 'bg-accent/5 border-accent/30'
                      : 'bg-secondary border-border opacity-60'
                  }`}
                >
                  <div className="flex-shrink-0">
                    {weekComplete ? (
                      <CheckCircle className="w-5 h-5 text-accent" />
                    ) : isUnlocked ? (
                      <div className="w-5 h-5 rounded-full border-2 border-accent" />
                    ) : (
                      <Lock className="w-5 h-5 text-muted-foreground" />
                    )}
                  </div>

                  <span className={`font-medium flex-1 ${isUnlocked ? 'text-foreground' : 'text-muted-foreground'}`}>
                    Week {week.number} — {week.title}
                  </span>

                  {weekComplete && (
                    <span className="text-xs text-accent font-semibold uppercase tracking-wide">
                      Complete
                    </span>
                  )}

                  {!isUnlocked && (
                    <Link
                      to="/sprint"
                      className="text-xs text-accent hover:underline underline-offset-2 flex items-center gap-1 flex-shrink-0"
                    >
                      Unlock with Sprint
                      <ArrowRight className="w-3 h-3" />
                    </Link>
                  )}
                </div>
              );
            })}
          </div>

          {!sprintUnlocked && (
            <div className="mt-6 p-5 rounded-xl bg-secondary border border-border text-center">
              <p className="text-muted-foreground mb-4">
                Weeks 2–6 unlock after purchasing the MindShift Sprint.
                Content unlocks one week at a time on a 7-day cadence.
              </p>
              <Button
                variant="default"
                size="lg"
                className="bg-gradient-gold text-background font-bold hover:shadow-glow transition-all duration-300"
                asChild
              >
                <Link to="/sprint">
                  Unlock the MindShift Sprint
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          )}
        </section>
      </main>

      <footer className="border-t border-border mt-4">
        <div className="container-premium py-6">
          <p className="text-center text-sm text-muted-foreground">
            © {new Date().getFullYear()} Pat & Chris Coaching. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default WeekOneContent;
